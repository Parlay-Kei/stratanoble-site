# Strata Noble Brand Style Guide

## Brand Essence
Navigation. Ascension. Guidance. Make it simple to win.

## Mission
Help people turn passion and operational pain points into profit with strategy, systems, and momentum.

## Voice and Tone
Plainspoken. Precise. No filler. Confident but not loud. Avoid corporate fluff.

## Colors
- Navy Blue #003366 (primary)
- Silver Grey #C0C0C0 (support)
- Emerald Green #50C878 (accent)

## Typography
- Heading: Inter or similar geometric sans, bold
- Body: Inter Regular
- Numeric and UI: Monospace acceptable in technical docs

## Logo and Marks
- Wordmark: STRATA NOBLE in Navy
- Accent motif: subtle compass or ascension marker
- Do not use drop shadows or gradients

## Messaging Pillars
1. Strategy you can act on today
2. Systems that reduce touches and shrink waste
3. Momentum that compounds

## One Liner
A simple way to turn daily actions into real achievements.

## Content Rules
- No em dashes
- Short sentences
- Show steps and outcomes
