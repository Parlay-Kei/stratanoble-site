# Production Maintenance and Deployment

## Purpose
Keep releases safe and boring. Protect the brand and the data.

## Checklist
1. Branch policy with review
2. Lint, type check, and tests
3. Build on CI with environment matrix
4. Database migrations reviewed and reversible
5. Feature flags for risky changes
6. Rollout with canary
7. Monitor error rate and Core Web Vitals
8. Rollback plan documented

## Environments
- Staging on Netlify with SES sandbox
- Production on Netlify with SES production

## Logs and Alerts
- Centralized error tracking
- Uptime monitor on homepage and API
