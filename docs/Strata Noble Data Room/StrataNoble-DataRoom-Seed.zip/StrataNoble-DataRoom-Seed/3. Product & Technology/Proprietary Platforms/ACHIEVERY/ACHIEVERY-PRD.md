# ACHIEVERY — Product Requirements Document

## Problem
People stall because plans are abstract and days are chaotic. They need a simple rhythm that makes progress visible and addictive in a healthy way.

## Users
- Solo founders and operators
- Strata Noble clients during sprints
- Anyone who wants achievement over gamification

## Core Jobs
- Capture the next right actions
- Turn actions into streaks and proofs
- Reflect progress with calm metrics

## MVP Scope
- Daily Actions board with three tiers: Must, Move, Maintain
- Proof Log: quick capture of outcomes and notes
- Review: weekly summary with highlights and misses
- Export to PDF for clients and investors

## Non Goals
- Social feeds
- Public points
- Heavy task management

## Tech Notes
- Next.js app integrated into StrataNoble.com
- Supabase auth and tables
- Simple API for posting actions and proofs
