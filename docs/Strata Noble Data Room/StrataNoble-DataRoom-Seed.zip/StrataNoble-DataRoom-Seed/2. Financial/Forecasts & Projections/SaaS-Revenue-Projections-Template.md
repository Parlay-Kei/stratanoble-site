# SaaS Revenue Projections Template

## Assumptions
- Two client platforms licensed in Year 1
- Seat based pricing with base platform fee
- ACHIEVERY freemium with Pro tier

## Table
- MRR by product
- Churn assumption
- CAC simple payback estimate
- 12 month forecast with three cases: base, low, high

## Notes
Update monthly. Keep drivers visible above the table.
