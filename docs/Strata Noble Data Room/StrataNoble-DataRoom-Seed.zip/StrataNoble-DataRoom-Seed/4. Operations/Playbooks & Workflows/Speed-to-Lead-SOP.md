# Speed to Lead SOP

## Purpose
Respond fast. Book the right meetings. Respect attention.

## Targets
- Under 5 minutes response during business hours
- First meeting booked within 24 hours of form submit

## Flow
1. Form submit hits Q by Strata Noble
2. Auto score and route to inbox
3. Sequence sends a short confirmation with two time options
4. Manual follow up if no reply in 4 hours
5. Close the loop with a simple summary of value and next step

## Scripts
- Confirmation: short, human, one ask
- Nurture: one proof, one step

## Metrics
- Response time
- Booked rate
- No show rate
