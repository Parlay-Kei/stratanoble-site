# Client Discovery Playbook

## Goal
Understand the job, the constraint, and the measure of success in the first session.

## Steps
1. Context: who is the buyer and who is the user
2. Problem: what is blocking progress right now
3. Constraint: where does time or money leak
4. Measure: what proves we fixed it
5. Scope: three wins we can earn in two weeks
6. Decision: schedule, owner, and next action

## Artifacts
- Discovery notes in client folder
- One page plan with three wins
- First invoice or SOW
