# SOC 2 Lite Readiness Checklist

## Governance
- Role and permission inventory
- Vendor list with data flows
- Incident response draft

## Access
- Least privilege on Supabase
- RLS policies reviewed
- Key rotation schedule

## Integrity
- Lint and type gates on CI
- Required code review
- Backups tested

## Privacy
- PII inventory
- Data retention policy
- Right to delete process

## Security
- Dependency scanning
- CSP and headers
- Secrets in vault
