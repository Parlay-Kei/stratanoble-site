# AspireNexis Holding Structure

## Purpose
Hold IP and equity positions across Strata Noble initiatives.

## Entities
- AspireNexis Holding
- Strata Noble Consulting
- Project level SPVs if required

## Ownership Principles
- Clear IP assignment per project
- Non dilutable positions where negotiated
- Simple reporting and cash flow rules
